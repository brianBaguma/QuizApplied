package model;

public class Phone_Number {

        private String number;
        private String label;

        public Phone_Number(String number, String label) {
            this.number = number;
            this.label = label;
        }

        // Getters and setters omitted for brevity
    }


