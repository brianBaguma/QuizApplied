package model;



public class Email_Address {
    private String address;
    private String label;

    public Email_Address(String address, String label) {
        this.address = address;
        this.label = label;
    }

    // Getters and setters omitted for brevity
}


