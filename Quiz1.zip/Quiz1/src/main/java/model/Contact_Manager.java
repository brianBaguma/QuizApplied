package model;

public class Contact_Manager {
}
